import { useState, useCallback, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Toaster, toast } from 'sonner';
import { UploadScreen } from './components/UploadScreen';
import { Header } from './components/Header';
import { Toolbar } from './components/Toolbar';
import { GuideList } from './components/GuideList';
import { SummaryModal } from './components/SummaryModal';
import { useSound } from './hooks/useSound';
import { useDataStorage } from './hooks/useDataStorage';
import { useSecretMode } from './hooks/useSecretMode';
import { useExcelProcessor } from './hooks/useExcelProcessor';
import type { ExcelRow } from './types';
import './App.css';

function App() {
  // Data state
  const [allData, setAllData] = useState<ExcelRow[]>([]);
  const [filteredData, setFilteredData] = useState<ExcelRow[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showSummary, setShowSummary] = useState(false);
  const [showUpload, setShowUpload] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);

  // Hooks
  const { playSound } = useSound();
  const { storedData, hasStoredData, isLoaded, saveData, clearData, getLastUpdated } = useDataStorage();
  const { progress, isProcessing, processFile } = useExcelProcessor();

  // Secret mode
  const handleSecretActivate = useCallback(() => {
    playSound('secret');
    toast.success('Modo Administrador Activado', {
      description: 'Ahora puedes gestionar los datos',
      icon: '🔐'
    });
  }, [playSound]);

  const handleSecretDeactivate = useCallback(() => {
    playSound('click');
  }, [playSound]);

  const { isSecretMode, handleLogoClick, exitSecretMode, getClickProgress } = useSecretMode(
    handleSecretActivate,
    handleSecretDeactivate
  );

  // Load stored data on mount
  useEffect(() => {
    if (isLoaded && !isInitialized) {
      if (hasStoredData && storedData.length > 0) {
        setAllData(storedData);
        setFilteredData(storedData);
        const lastUpdated = getLastUpdated();
        if (lastUpdated) {
          const date = new Date(lastUpdated);
          toast.info('Datos cargados', {
            description: `Última actualización: ${date.toLocaleDateString('es-PE')} ${date.toLocaleTimeString('es-PE')}`,
          });
        }
      }
      setIsInitialized(true);
    }
  }, [isLoaded, hasStoredData, storedData, isInitialized, getLastUpdated]);

  // Filter data when search term changes
  useEffect(() => {
    if (!searchTerm) {
      setFilteredData(allData);
      return;
    }

    const terms = searchTerm.split(' ').filter(t => t.length > 0);
    const filtered = allData.filter(item => {
      const nameMatch = terms.every(t => item.name.includes(t));
      const guideMatch = item.simpleGuide.includes(searchTerm);
      return nameMatch || guideMatch;
    });
    setFilteredData(filtered);
  }, [searchTerm, allData]);

  // KPI calculations
  const { kpiCount, kpiDrivers, kpiTotal } = useMemo(() => {
    const total = filteredData.reduce((sum, item) => sum + item.total, 0);
    const uniqueDrivers = new Set(filteredData.map(i => i.name)).size;
    return {
      kpiCount: filteredData.length,
      kpiDrivers: uniqueDrivers,
      kpiTotal: total.toLocaleString('es-PE', { style: 'currency', currency: 'PEN' })
    };
  }, [filteredData]);

  // Handle file upload
  const handleFileSelect = useCallback(async (file: File) => {
    try {
      playSound('upload');
      const processedData = await processFile(file);
      
      setAllData(processedData);
      setFilteredData(processedData);
      saveData(processedData, file.name);
      
      playSound('success');
      toast.success('Archivo procesado correctamente', {
        description: `${processedData.length} registros cargados`,
      });
      
      setShowUpload(false);
      exitSecretMode();
    } catch (error) {
      playSound('error');
      toast.error('Error al procesar el archivo', {
        description: 'Verifica que sea un archivo Excel válido',
      });
    }
  }, [processFile, saveData, playSound, exitSecretMode]);

  // Handle clear data
  const handleClearData = useCallback(() => {
    if (confirm('¿Estás seguro de que deseas eliminar todos los datos?')) {
      clearData();
      setAllData([]);
      setFilteredData([]);
      setSearchTerm('');
      playSound('delete');
      toast.success('Datos eliminados', {
        description: 'Todos los registros han sido borrados',
      });
      exitSecretMode();
    }
  }, [clearData, playSound, exitSecretMode]);

  // Handle copy to clipboard
  const handleCopy = useCallback((text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      playSound('click');
      toast.success('Copiado al portapapeles', {
        description: text,
        duration: 2000,
      });
    });
  }, [playSound]);

  // Handle download CSV
  const handleDownloadCSV = useCallback(() => {
    let csv = 'Fecha,Nombre_Conductor,Tipo_Registro,Codigo_Guia,Estado,Monto_Pagado,Notas\n';
    filteredData.forEach(row => {
      if (row.price > 0) {
        csv += `${row.dateStr},"${row.name}","GUIA","${row.simpleGuide}","PAGADO",${row.price.toFixed(2)},"Pago Regular"\n`;
      }
      if (row.bonus > 0) {
        csv += `${row.dateStr},"${row.name}","BONO","MANUAL","BONO_EXTRA",${row.bonus.toFixed(2)},"Incentivo Adicional"\n`;
      }
    });

    const link = document.createElement('a');
    link.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    link.download = `Auditoria_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();

    playSound('success');
    toast.success('CSV descargado');
  }, [filteredData, playSound]);

  // Handle search change
  const handleSearchChange = useCallback((value: string) => {
    setSearchTerm(value);
    if (value) {
      playSound('hover');
    }
  }, [playSound]);

  // Show upload screen if no data or explicitly showing upload
  const shouldShowUpload = showUpload || (isInitialized && !hasStoredData && allData.length === 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/30">
      <Toaster 
        position="top-right" 
        richColors 
        closeButton
        toastOptions={{
          style: {
            fontFamily: 'Inter, sans-serif',
          },
        }}
      />

      <AnimatePresence>
        {shouldShowUpload && (
          <UploadScreen
            onFileSelect={handleFileSelect}
            progress={progress}
            isProcessing={isProcessing}
          />
        )}
      </AnimatePresence>

      {(!shouldShowUpload || allData.length > 0) && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col min-h-screen"
        >
          <Header
            isSecretMode={isSecretMode}
            onLogoClick={handleLogoClick}
            clickProgress={getClickProgress()}
            onUploadClick={() => setShowUpload(true)}
            onClearClick={handleClearData}
            onExitSecretMode={exitSecretMode}
            kpiCount={kpiCount}
            kpiDrivers={kpiDrivers}
            kpiTotal={kpiTotal}
          />

          <Toolbar
            searchTerm={searchTerm}
            onSearchChange={handleSearchChange}
            onShowSummary={() => {
              playSound('click');
              setShowSummary(true);
            }}
            onDownloadCSV={handleDownloadCSV}
            resultCount={filteredData.length}
            totalCount={allData.length}
          />

          <main className="flex-1 overflow-auto">
            <GuideList data={filteredData} onCopy={handleCopy} />
          </main>
        </motion.div>
      )}

      <SummaryModal
        isOpen={showSummary}
        onClose={() => {
          playSound('click');
          setShowSummary(false);
        }}
        data={filteredData}
        onCopy={handleCopy}
      />
    </div>
  );
}

export default App;
