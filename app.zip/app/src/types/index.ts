export interface ExcelRow {
  name: string;
  simpleGuide: string;
  price: number;
  bonus: number;
  total: number;
  dateStr: string;
}

export interface DriverGroup {
  name: string;
  count: number;
  total: number;
  guides: GuideItem[];
  bonuses: BonusItem[];
}

export interface GuideItem {
  code: string;
  price: number;
  date: string;
}

export interface BonusItem {
  code: string;
  price: number;
  date: string;
}

export interface DayGroup {
  dateKey: string;
  items: GuideItem[];
  totalDay: number;
  dateObj: Date;
}

export interface StoredData {
  data: ExcelRow[];
  timestamp: number;
  fileName?: string;
}
