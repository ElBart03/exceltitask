import { useState, useCallback } from 'react';
import * as XLSX from 'xlsx';
import type { ExcelRow } from '@/types';

const COLS = { DATE: 1, GUIDE: 9, NAME: 13, PRICE: 22, BONUS: 23 };

interface ProcessProgress {
  percentage: number;
  message: string;
}

export function useExcelProcessor() {
  const [progress, setProgress] = useState<ProcessProgress>({ percentage: 0, message: '' });
  const [isProcessing, setIsProcessing] = useState(false);

  const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  const updateProgress = useCallback((percentage: number, message: string) => {
    setProgress({ percentage, message });
  }, []);

  const processFile = useCallback(async (file: File): Promise<ExcelRow[]> => {
    setIsProcessing(true);
    setProgress({ percentage: 0, message: 'Iniciando...' });

    try {
      updateProgress(10, 'Cargando archivo...');
      await delay(300);

      const arrayBuffer = await file.arrayBuffer();
      
      updateProgress(30, 'Leyendo estructura Excel...');
      await delay(300);

      const workbook = XLSX.read(new Uint8Array(arrayBuffer), { type: 'array', cellDates: true });
      
      updateProgress(50, 'Cargando pagos y celdas...');
      await delay(300);

      let sheetName = workbook.SheetNames.find(n => n.toLowerCase().match(/(planilla|pagos|reporte)/)) || workbook.SheetNames[0];
      const ws = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, blankrows: false }) as (string | number | Date | null)[][];

      updateProgress(70, 'Separando bonos manuales...');
      await delay(300);

      let headerRow = 0;
      for (let i = 0; i < Math.min(30, jsonData.length); i++) {
        const rowStr = JSON.stringify(jsonData[i]).toLowerCase();
        if (rowStr.includes('activación') || rowStr.includes('guia')) {
          headerRow = i;
          break;
        }
      }

      const processedData: ExcelRow[] = [];

      for (let i = headerRow + 1; i < jsonData.length; i++) {
        const row = jsonData[i];
        if (!row) continue;

        const rawName = row[COLS.NAME];
        const rawGuide = row[COLS.GUIDE];

        if (!rawName && !rawGuide) continue;

        let name = rawName ? String(rawName).toUpperCase().trim().replace(/\s+/g, ' ') : 'SIN NOMBRE';
        if (name.includes('TOTAL') || name.includes('PÁGINA')) continue;

        let rawGuideStr = rawGuide ? String(rawGuide).trim() : '';
        let simpleGuide = 'S/N';
        const match8 = rawGuideStr.match(/(\d{8})/);
        if (match8) simpleGuide = match8[0];
        else if (rawGuideStr.length > 0) simpleGuide = rawGuideStr;

        let rawPrice = row[COLS.PRICE];
        let basePrice = 0;
        if (typeof rawPrice === 'number') basePrice = rawPrice;
        else if (rawPrice) basePrice = parseFloat(String(rawPrice).replace(/[^\d.-]/g, '')) || 0;

        let rawBonus = row[COLS.BONUS];
        let bonus = 0;
        if (typeof rawBonus === 'number') bonus = rawBonus;
        else if (rawBonus) bonus = parseFloat(String(rawBonus).replace(/[^\d.-]/g, '')) || 0;

        let totalRowPrice = basePrice + bonus;

        let rawDate = row[COLS.DATE];
        let dateStr = '';
        if (rawDate instanceof Date) {
          dateStr = rawDate.toLocaleDateString('es-PE', { day: '2-digit', month: '2-digit', year: 'numeric' });
        } else if (rawDate) {
          dateStr = String(rawDate).trim();
        }

        processedData.push({
          name,
          simpleGuide,
          price: basePrice,
          bonus,
          total: totalRowPrice,
          dateStr
        });
      }

      processedData.sort((a, b) => b.total - a.total);

      updateProgress(100, '¡Listo!');
      await delay(300);

      return processedData;
    } catch (error) {
      console.error('Error processing file:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, [updateProgress, delay]);

  return {
    progress,
    isProcessing,
    processFile
  };
}
