import { useState, useCallback, useRef } from 'react';

const CLICK_THRESHOLD = 5;
const CLICK_TIMEOUT = 2000;

export function useSecretMode(onActivate?: () => void, onDeactivate?: () => void) {
  const [isSecretMode, setIsSecretMode] = useState(false);
  const clickCountRef = useRef(0);
  const clickTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastClickTimeRef = useRef(0);

  const handleLogoClick = useCallback(() => {
    const now = Date.now();
    
    // Reset si pasó mucho tiempo entre clics
    if (now - lastClickTimeRef.current > CLICK_TIMEOUT) {
      clickCountRef.current = 0;
    }
    lastClickTimeRef.current = now;

    clickCountRef.current++;

    // Limpiar timer anterior
    if (clickTimerRef.current) {
      clearTimeout(clickTimerRef.current);
    }

    // Set nuevo timer para resetear
    clickTimerRef.current = setTimeout(() => {
      clickCountRef.current = 0;
    }, CLICK_TIMEOUT);

    // Activar modo secreto
    if (clickCountRef.current >= CLICK_THRESHOLD) {
      clickCountRef.current = 0;
      if (clickTimerRef.current) {
        clearTimeout(clickTimerRef.current);
      }
      
      const newMode = !isSecretMode;
      setIsSecretMode(newMode);
      
      if (newMode && onActivate) {
        onActivate();
      } else if (!newMode && onDeactivate) {
        onDeactivate();
      }
    }

    return clickCountRef.current;
  }, [isSecretMode, onActivate, onDeactivate]);

  const exitSecretMode = useCallback(() => {
    setIsSecretMode(false);
    if (onDeactivate) {
      onDeactivate();
    }
  }, [onDeactivate]);

  const getClickProgress = useCallback(() => {
    return Math.min(clickCountRef.current / CLICK_THRESHOLD, 1);
  }, []);

  return {
    isSecretMode,
    handleLogoClick,
    exitSecretMode,
    getClickProgress,
    clickCount: clickCountRef.current
  };
}
