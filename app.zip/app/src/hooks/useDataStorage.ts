import { useState, useEffect, useCallback } from 'react';
import type { ExcelRow, StoredData } from '@/types';

const STORAGE_KEY = 'auditor_pro_data_v1';

export function useDataStorage() {
  const [storedData, setStoredData] = useState<ExcelRow[]>([]);
  const [hasStoredData, setHasStoredData] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  // Cargar datos al iniciar
  useEffect(() => {
    const loadData = () => {
      try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          const parsed: StoredData = JSON.parse(stored);
          if (parsed.data && Array.isArray(parsed.data)) {
            setStoredData(parsed.data);
            setHasStoredData(true);
          }
        }
      } catch (error) {
        console.error('Error loading stored data:', error);
      }
      setIsLoaded(true);
    };

    loadData();
  }, []);

  // Guardar datos
  const saveData = useCallback((data: ExcelRow[], fileName?: string) => {
    try {
      const toStore: StoredData = {
        data,
        timestamp: Date.now(),
        fileName
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(toStore));
      setStoredData(data);
      setHasStoredData(true);
      return true;
    } catch (error) {
      console.error('Error saving data:', error);
      return false;
    }
  }, []);

  // Eliminar datos
  const clearData = useCallback(() => {
    try {
      localStorage.removeItem(STORAGE_KEY);
      setStoredData([]);
      setHasStoredData(false);
      return true;
    } catch (error) {
      console.error('Error clearing data:', error);
      return false;
    }
  }, []);

  // Obtener timestamp de última actualización
  const getLastUpdated = useCallback(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed: StoredData = JSON.parse(stored);
        return parsed.timestamp;
      }
    } catch (error) {
      console.error('Error getting timestamp:', error);
    }
    return null;
  }, []);

  return {
    storedData,
    hasStoredData,
    isLoaded,
    saveData,
    clearData,
    getLastUpdated
  };
}
