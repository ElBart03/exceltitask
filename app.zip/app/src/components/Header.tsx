import { motion, AnimatePresence } from 'framer-motion';
import { Wallet, Shield, Trash2, Upload, X, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface HeaderProps {
  isSecretMode: boolean;
  onLogoClick: () => void;
  clickProgress: number;
  onUploadClick: () => void;
  onClearClick: () => void;
  onExitSecretMode: () => void;
  kpiCount: number;
  kpiDrivers: number;
  kpiTotal: string;
}

export function Header({
  isSecretMode,
  onLogoClick,
  clickProgress,
  onUploadClick,
  onClearClick,
  onExitSecretMode,
  kpiCount,
  kpiDrivers,
  kpiTotal
}: HeaderProps) {
  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="bg-white/80 backdrop-blur-xl border-b border-slate-200/50 sticky top-0 z-40"
    >
      <div className="px-4 sm:px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          {/* Logo */}
          <motion.div 
            className="flex items-center gap-3 relative"
            onClick={onLogoClick}
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="relative cursor-pointer select-none"
            >
              <div className={`
                w-12 h-12 rounded-xl flex items-center justify-center
                transition-all duration-300
                ${isSecretMode 
                  ? 'bg-gradient-to-br from-amber-500 to-orange-600 shadow-lg shadow-amber-500/30' 
                  : 'bg-gradient-to-br from-blue-600 to-indigo-700 shadow-lg shadow-blue-500/30'
                }
              `}>
                {isSecretMode ? (
                  <Shield className="w-6 h-6 text-white" />
                ) : (
                  <Wallet className="w-6 h-6 text-white" />
                )}
              </div>
              
              {/* Click progress indicator */}
              {!isSecretMode && clickProgress > 0 && (
                <svg className="absolute -inset-1 w-14 h-14 -rotate-90">
                  <circle
                    cx="28"
                    cy="28"
                    r="26"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    className="text-slate-200"
                  />
                  <motion.circle
                    cx="28"
                    cy="28"
                    r="26"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    className="text-blue-500"
                    strokeDasharray={`${2 * Math.PI * 26}`}
                    initial={{ strokeDashoffset: `${2 * Math.PI * 26}` }}
                    animate={{ strokeDashoffset: `${2 * Math.PI * 26 * (1 - clickProgress)}` }}
                  />
                </svg>
              )}
            </motion.div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className={`
                  text-xl font-bold tracking-tight
                  ${isSecretMode ? 'text-amber-600' : 'text-slate-800'}
                `}>
                  {isSecretMode ? 'Modo Admin' : 'Auditor Pro'}
                </h1>
                <Badge variant="secondary" className="text-xs font-mono">
                  3.0
                </Badge>
              </div>
              <p className="text-xs text-slate-500">
                {isSecretMode ? 'Acceso concedido' : 'By ElBartO'}
              </p>
            </div>
          </motion.div>

          {/* KPIs */}
          <div className="flex items-center gap-6 sm:gap-8">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="text-right"
            >
              <p className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                Guías
              </p>
              <p className="text-lg font-bold text-slate-800">
                {kpiCount.toLocaleString()}
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="text-right"
            >
              <p className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                Conductores
              </p>
              <p className="text-lg font-bold text-slate-800">
                {kpiDrivers.toLocaleString()}
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="text-right"
            >
              <p className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                Total Neto
              </p>
              <p className="text-lg font-bold text-emerald-600">
                {kpiTotal}
              </p>
            </motion.div>
          </div>
        </div>

        {/* Secret Mode Panel */}
        <AnimatePresence>
          {isSecretMode && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="mt-4 pt-4 border-t border-amber-200/50">
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-2 text-amber-700">
                    <Lock className="w-4 h-4" />
                    <span className="text-sm font-medium">Panel de Administración</span>
                  </div>
                  
                  <div className="flex-1" />
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={onUploadClick}
                    className="border-amber-300 hover:bg-amber-50 text-amber-700"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Subir Nuevo Excel
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={onClearClick}
                    className="border-red-300 hover:bg-red-50 text-red-600"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Borrar Datos
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onExitSecretMode}
                    className="text-slate-500"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Cerrar
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.header>
  );
}
