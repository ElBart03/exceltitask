import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, List, Download, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

interface ToolbarProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  onShowSummary: () => void;
  onDownloadCSV: () => void;
  resultCount: number;
  totalCount: number;
}

export function Toolbar({
  searchTerm,
  onSearchChange,
  onShowSummary,
  onDownloadCSV,
  resultCount,
  totalCount
}: ToolbarProps) {
  const [isFocused, setIsFocused] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="bg-white/60 backdrop-blur-lg border-b border-slate-200/50 px-4 sm:px-6 py-4"
    >
      <div className="flex flex-col sm:flex-row gap-4">
        {/* Action Buttons */}
        <div className="flex gap-2">
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button
              onClick={onShowSummary}
              className="bg-slate-800 hover:bg-slate-900 text-white shadow-lg shadow-slate-500/20"
            >
              <List className="w-4 h-4 mr-2" />
              Resumen
            </Button>
          </motion.div>
          
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button
              variant="outline"
              onClick={onDownloadCSV}
              className="border-emerald-300 text-emerald-700 hover:bg-emerald-50"
            >
              <Download className="w-4 h-4 mr-2" />
              Exportar
            </Button>
          </motion.div>
        </div>

        {/* Search */}
        <div className="flex-1 relative">
          <motion.div
            animate={{ 
              scale: isFocused ? 1.01 : 1,
              boxShadow: isFocused 
                ? '0 0 0 3px rgba(59, 130, 246, 0.2)' 
                : '0 0 0 0px rgba(59, 130, 246, 0)'
            }}
            className="relative rounded-xl"
          >
            <Search className={`
              absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 transition-colors
              ${isFocused ? 'text-blue-500' : 'text-slate-400'}
            `} />
            <Input
              type="text"
              placeholder="Buscar conductor o código de guía..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value.toUpperCase())}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              className={`
                pl-12 pr-4 py-3 h-12 rounded-xl
                bg-white border-slate-200
                text-slate-800 placeholder:text-slate-400
                transition-all duration-200
                focus:border-blue-500 focus:ring-0
              `}
            />
            
            {/* Results badge */}
            {searchTerm && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute right-3 top-1/2 -translate-y-1/2"
              >
                <Badge variant="secondary" className="text-xs">
                  {resultCount} / {totalCount}
                </Badge>
              </motion.div>
            )}
          </motion.div>
        </div>

        {/* Filter indicator */}
        {searchTerm && (
          <motion.div
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2 text-sm text-slate-500"
          >
            <Filter className="w-4 h-4" />
            <span>Filtrando</span>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
