import { motion } from 'framer-motion';
import { Copy, Check, Calendar } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

interface GuideCardProps {
  price: number;
  simpleGuide: string;
  dateStr: string;
  index: number;
  onCopy: (text: string) => void;
}

export function GuideCard({ price, simpleGuide, dateStr, index, onCopy }: GuideCardProps) {
  const [isCopied, setIsCopied] = useState(false);

  const formatMoney = (amount: number) => {
    return amount.toLocaleString('es-PE', { style: 'currency', currency: 'PEN' });
  };

  const handleCopy = () => {
    onCopy(simpleGuide);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ delay: index * 0.03, type: "spring", stiffness: 300, damping: 25 }}
      whileHover={{ scale: 1.01, y: -2 }}
      className="group relative bg-white rounded-2xl p-5 shadow-sm border border-slate-100 hover:shadow-lg hover:border-blue-200 transition-all duration-300"
    >
      {/* Price section */}
      <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
        <span className="text-sm text-slate-400 font-medium">Pago Guía</span>
        <span className="text-2xl font-bold text-slate-800">
          {formatMoney(price)}
        </span>
      </div>

      {/* Guide code section */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="px-3 py-1.5 bg-blue-50 rounded-lg">
            <span className="font-semibold text-blue-700 tracking-wide">
              {simpleGuide}
            </span>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={handleCopy}
            className={`
              w-8 h-8 rounded-lg transition-all duration-200
              ${isCopied 
                ? 'bg-emerald-100 text-emerald-600' 
                : 'text-slate-400 hover:text-blue-500 hover:bg-blue-50'
              }
            `}
          >
            <motion.div
              initial={false}
              animate={{ scale: isCopied ? [1, 1.2, 1] : 1 }}
            >
              {isCopied ? (
                <Check className="w-4 h-4" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </motion.div>
          </Button>
        </div>

        {/* Date */}
        <div className="flex items-center gap-2 text-slate-400">
          <Calendar className="w-4 h-4" />
          <span className="text-sm">{dateStr}</span>
        </div>
      </div>

      {/* Hover glow effect */}
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-500/0 via-blue-500/5 to-blue-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
    </motion.div>
  );
}
