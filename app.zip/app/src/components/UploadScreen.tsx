import { useRef, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CloudUpload, FileSpreadsheet, Sparkles } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

interface UploadScreenProps {
  onFileSelect: (file: File) => void;
  progress: { percentage: number; message: string };
  isProcessing: boolean;
}

export function UploadScreen({ onFileSelect, progress, isProcessing }: UploadScreenProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleClick = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileSelect(file);
    }
  }, [onFileSelect]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && (file.name.endsWith('.xlsx') || file.name.endsWith('.xls'))) {
      onFileSelect(file);
    }
  }, [onFileSelect]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-6"
    >
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.2, 0.1],
            rotate: [0, 180, 360]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute -top-1/4 -right-1/4 w-[600px] h-[600px] rounded-full bg-blue-400/20 blur-3xl"
        />
        <motion.div
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.1, 0.15, 0.1]
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -bottom-1/4 -left-1/4 w-[500px] h-[500px] rounded-full bg-indigo-400/20 blur-3xl"
        />
      </div>

      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
        className="relative z-10"
      >
        <AnimatePresence mode="wait">
          {!isProcessing ? (
            <motion.div
              key="upload"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              onClick={handleClick}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`
                relative cursor-pointer group
                w-full max-w-md p-12 rounded-3xl
                bg-white/80 backdrop-blur-xl
                border-2 border-dashed transition-all duration-300
                shadow-2xl shadow-blue-500/10
                ${isDragging 
                  ? 'border-blue-500 bg-blue-50/80 scale-105' 
                  : 'border-slate-300 hover:border-blue-400 hover:shadow-blue-500/20 hover:scale-[1.02]'
                }
              `}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileChange}
                className="hidden"
              />
              
              <div className="flex flex-col items-center text-center">
                <motion.div
                  animate={{ y: [0, -8, 0] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  className={`
                    w-24 h-24 rounded-2xl flex items-center justify-center mb-6
                    transition-colors duration-300
                    ${isDragging ? 'bg-blue-500' : 'bg-gradient-to-br from-blue-500 to-indigo-600 group-hover:from-blue-600 group-hover:to-indigo-700'}
                  `}
                >
                  <CloudUpload className="w-12 h-12 text-white" />
                </motion.div>

                <h2 className="text-2xl font-bold text-slate-800 mb-2">
                  Subir Planilla
                </h2>
                <p className="text-slate-500 mb-4">
                  Arrastra tu archivo Excel o toca para seleccionar
                </p>

                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>.xlsx, .xls</span>
                </div>

                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: isDragging ? 1 : 0, scale: isDragging ? 1 : 0.8 }}
                  className="absolute inset-0 flex items-center justify-center bg-blue-500/10 rounded-3xl"
                >
                  <span className="text-blue-600 font-semibold text-lg">Suelta aquí</span>
                </motion.div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="progress"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="w-full max-w-md p-10 rounded-3xl bg-white/90 backdrop-blur-xl shadow-2xl shadow-blue-500/10"
            >
              <div className="flex flex-col items-center">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center mb-6"
                >
                  <Sparkles className="w-10 h-10 text-white" />
                </motion.div>

                <h3 className="text-xl font-semibold text-slate-800 mb-6">
                  Procesando...
                </h3>

                <div className="w-full space-y-3">
                  <Progress 
                    value={progress.percentage} 
                    className="h-3 bg-slate-100"
                  />
                  <motion.p 
                    key={progress.message}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center text-slate-500 text-sm"
                  >
                    {progress.message}
                  </motion.p>
                </div>

                <div className="mt-6 flex gap-1">
                  {[0, 1, 2].map((i) => (
                    <motion.div
                      key={i}
                      animate={{ 
                        scale: [1, 1.5, 1],
                        opacity: [0.5, 1, 0.5]
                      }}
                      transition={{ 
                        duration: 1, 
                        repeat: Infinity, 
                        delay: i * 0.2 
                      }}
                      className="w-2 h-2 rounded-full bg-blue-500"
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Signature */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="absolute bottom-8 font-mono text-xs text-slate-400"
      >
        By ElBartO
      </motion.div>
    </motion.div>
  );
}
