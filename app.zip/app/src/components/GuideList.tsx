import { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BonusCard } from './BonusCard';
import { GuideCard } from './GuideCard';
import type { ExcelRow } from '@/types';

interface GuideListProps {
  data: ExcelRow[];
  onCopy: (text: string) => void;
}

export function GuideList({ data, onCopy }: GuideListProps) {
  const { displayData, totalBonus, bonusCount, hasMore } = useMemo(() => {
    const limit = 200;
    const displayData = data.slice(0, limit);
    
    let totalBonus = 0;
    let bonusCount = 0;
    
    displayData.forEach(item => {
      if (item.bonus > 0) {
        totalBonus += item.bonus;
        bonusCount++;
      }
    });

    const hasMore = data.length > limit;

    return { displayData, totalBonus, bonusCount, hasMore };
  }, [data]);

  // Filter only items with price > 0 or (price === 0 and bonus === 0)
  const filteredDisplayData = displayData.filter(
    item => item.price > 0 || (item.price === 0 && item.bonus === 0)
  );

  return (
    <div className="p-4 sm:p-6">
      {/* Section Title */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="mb-4"
      >
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">
          Historial de Guías
        </h3>
        <p className="text-xs text-slate-400 mt-1">
          Mostrando {filteredDisplayData.length} de {data.length} registros
        </p>
      </motion.div>

      {/* Bonus Card */}
      <AnimatePresence>
        {totalBonus > 0 && (
          <BonusCard totalBonus={totalBonus} count={bonusCount} />
        )}
      </AnimatePresence>

      {/* Guide Cards */}
      <div className="space-y-3">
        <AnimatePresence mode="popLayout">
          {filteredDisplayData.map((item, index) => (
            <GuideCard
              key={`${item.simpleGuide}-${index}`}
              price={item.price}
              simpleGuide={item.simpleGuide}
              dateStr={item.dateStr}
              index={index}
              onCopy={onCopy}
            />
          ))}
        </AnimatePresence>

        {/* Load more indicator */}
        {hasMore && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-8 text-slate-400"
          >
            <div className="flex items-center justify-center gap-2">
              <div className="w-2 h-2 rounded-full bg-slate-300 animate-bounce" style={{ animationDelay: '0ms' }} />
              <div className="w-2 h-2 rounded-full bg-slate-300 animate-bounce" style={{ animationDelay: '150ms' }} />
              <div className="w-2 h-2 rounded-full bg-slate-300 animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
            <p className="text-sm mt-2">Visualizando primeros 200 registros</p>
          </motion.div>
        )}

        {/* Empty state */}
        {filteredDisplayData.length === 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-16"
          >
            <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-slate-100 flex items-center justify-center">
              <svg className="w-10 h-10 text-slate-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <p className="text-slate-500 font-medium">No se encontraron registros</p>
            <p className="text-sm text-slate-400 mt-1">Intenta con otra búsqueda</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
