import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronDown, ChevronUp, Copy, Check, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import type { ExcelRow } from '@/types';

interface SummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: ExcelRow[];
  onCopy: (text: string) => void;
}

interface DriverGroup {
  name: string;
  count: number;
  total: number;
  guides: { code: string; price: number; date: string }[];
  bonuses: { code: string; price: number; date: string }[];
}

const dayColors = [
  'bg-red-50 border-red-100',
  'bg-blue-50 border-blue-100',
  'bg-green-50 border-green-100',
  'bg-orange-50 border-orange-100',
  'bg-purple-50 border-purple-100',
  'bg-pink-50 border-pink-100',
  'bg-slate-50 border-slate-100'
];

const dayNames = ['DOMINGO', 'LUNES', 'MARTES', 'MIÉRCOLES', 'JUEVES', 'VIERNES', 'SÁBADO'];

export function SummaryModal({ isOpen, onClose, data, onCopy }: SummaryModalProps) {
  const [expandedDrivers, setExpandedDrivers] = useState<Set<string>>(new Set());
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const formatMoney = (amount: number) => {
    return amount.toLocaleString('es-PE', { style: 'currency', currency: 'PEN' });
  };

  const parseDate = (dateStr: string): Date => {
    if (!dateStr) return new Date();
    const parts = dateStr.split('/');
    return new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
  };

  // Group data by driver
  const groups: Record<string, DriverGroup> = {};
  data.forEach(item => {
    if (!groups[item.name]) {
      groups[item.name] = { name: item.name, count: 0, total: 0, guides: [], bonuses: [] };
    }
    groups[item.name].count++;
    groups[item.name].total += item.total;

    if (item.price > 0) {
      groups[item.name].guides.push({ code: item.simpleGuide, price: item.price, date: item.dateStr });
    }
    if (item.bonus > 0) {
      groups[item.name].bonuses.push({ code: 'BONO MANUAL', price: item.bonus, date: item.dateStr });
    }
  });

  const sortedDrivers = Object.values(groups).sort((a, b) => b.total - a.total);
  const grandTotal = sortedDrivers.reduce((sum, g) => sum + g.total, 0);

  const toggleDriver = (name: string) => {
    const newSet = new Set(expandedDrivers);
    if (newSet.has(name)) {
      newSet.delete(name);
    } else {
      newSet.add(name);
    }
    setExpandedDrivers(newSet);
  };

  const handleCopy = (code: string) => {
    onCopy(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-2xl max-h-[85vh] bg-white rounded-3xl shadow-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-white sticky top-0 z-10">
              <div>
                <h2 className="text-xl font-bold text-slate-800">Resumen Detallado</h2>
                <p className="text-sm text-slate-500">{sortedDrivers.length} conductores</p>
              </div>
              <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full">
                <X className="w-5 h-5" />
              </Button>
            </div>

            {/* Grand Total */}
            <div className="p-6 bg-gradient-to-r from-emerald-50 to-teal-50 border-b border-emerald-100">
              <div className="text-center">
                <p className="text-xs uppercase tracking-wider text-emerald-600 font-semibold mb-1">
                  Total General a Pagar
                </p>
                <p className="text-3xl font-bold text-emerald-700">
                  {formatMoney(grandTotal)}
                </p>
              </div>
            </div>

            {/* Driver List */}
            <ScrollArea className="h-[50vh]">
              <div className="p-4 space-y-3">
                {sortedDrivers.map((driver, idx) => {
                  const isExpanded = expandedDrivers.has(driver.name);
                  
                  // Group guides by date
                  const guidesByDate: Record<string, { items: typeof driver.guides; totalDay: number; dateObj: Date }> = {};
                  driver.guides.forEach(guide => {
                    if (!guidesByDate[guide.date]) {
                      guidesByDate[guide.date] = { items: [], totalDay: 0, dateObj: parseDate(guide.date) };
                    }
                    guidesByDate[guide.date].items.push(guide);
                    guidesByDate[guide.date].totalDay += guide.price;
                  });

                  const daysArray = Object.entries(guidesByDate)
                    .map(([dateKey, data]) => ({ dateKey, ...data }))
                    .sort((a, b) => a.dateObj.getTime() - b.dateObj.getTime());

                  const totalBonuses = driver.bonuses.reduce((sum, b) => sum + b.price, 0);

                  return (
                    <motion.div
                      key={driver.name}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="border border-slate-200 rounded-2xl overflow-hidden"
                    >
                      {/* Driver Header */}
                      <button
                        onClick={() => toggleDriver(driver.name)}
                        className="w-full flex items-center justify-between p-4 bg-white hover:bg-slate-50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold">
                            {driver.name.charAt(0)}
                          </div>
                          <div className="text-left">
                            <p className="font-semibold text-slate-800">{driver.name}</p>
                            <p className="text-xs text-slate-500">
                              {driver.count} {driver.count === 1 ? 'registro' : 'registros'}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-lg font-bold text-emerald-600">
                            {formatMoney(driver.total)}
                          </span>
                          {isExpanded ? (
                            <ChevronUp className="w-5 h-5 text-slate-400" />
                          ) : (
                            <ChevronDown className="w-5 h-5 text-slate-400" />
                          )}
                        </div>
                      </button>

                      {/* Driver Details */}
                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden bg-slate-50"
                          >
                            <div className="p-4 space-y-4">
                              {/* Days */}
                              {daysArray.map((day) => {
                                const dayIndex = day.dateObj.getDay();
                                const bgClass = dayColors[dayIndex];
                                
                                return (
                                  <div key={day.dateKey} className={`rounded-xl border ${bgClass} overflow-hidden`}>
                                    <div className="p-3 flex items-center justify-between border-b border-inherit">
                                      <div>
                                        <p className="font-semibold text-slate-700">{dayNames[dayIndex]}</p>
                                        <p className="text-xs text-slate-500">{day.dateKey}</p>
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <Badge variant="secondary" className="text-xs">
                                          {day.items.length} guías
                                        </Badge>
                                        <span className="font-semibold text-emerald-600">
                                          {formatMoney(day.totalDay)}
                                        </span>
                                      </div>
                                    </div>
                                    <div className="p-2 space-y-1">
                                      {day.items.map((item, itemIdx) => (
                                        <div
                                          key={itemIdx}
                                          className="flex items-center justify-between p-2 bg-white/60 rounded-lg"
                                        >
                                          <div className="flex items-center gap-2">
                                            <span className="text-xs text-slate-400 font-mono">#{itemIdx + 1}</span>
                                            <span className="font-mono font-semibold text-slate-700">{item.code}</span>
                                            <Button
                                              variant="ghost"
                                              size="icon"
                                              className="w-6 h-6"
                                              onClick={() => handleCopy(item.code)}
                                            >
                                              {copiedCode === item.code ? (
                                                <Check className="w-3 h-3 text-emerald-500" />
                                              ) : (
                                                <Copy className="w-3 h-3 text-blue-500" />
                                              )}
                                            </Button>
                                          </div>
                                          <span className="font-semibold text-slate-700">{formatMoney(item.price)}</span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                );
                              })}

                              {/* Bonuses */}
                              {driver.bonuses.length > 0 && (
                                <div className="rounded-xl border border-amber-200 bg-amber-50 overflow-hidden">
                                  <div className="p-3 flex items-center justify-between bg-amber-100 border-b border-amber-200">
                                    <div className="flex items-center gap-2">
                                      <Star className="w-4 h-4 text-amber-600" />
                                      <span className="font-semibold text-amber-800">Bonos Extras</span>
                                    </div>
                                    <span className="font-semibold text-amber-700">{formatMoney(totalBonuses)}</span>
                                  </div>
                                  <div className="p-2 space-y-1">
                                    {driver.bonuses.map((bonus, bIdx) => (
                                      <div
                                        key={bIdx}
                                        className="flex items-center justify-between p-2 bg-white/60 rounded-lg border border-dashed border-amber-300"
                                      >
                                        <div className="flex items-center gap-2">
                                          <span className="text-xs text-amber-600 font-mono">B{bIdx + 1}</span>
                                          <span className="text-sm text-amber-700">Bono Manual ({bonus.date})</span>
                                        </div>
                                        <span className="font-semibold text-amber-700">{formatMoney(bonus.price)}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })}
              </div>
            </ScrollArea>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
